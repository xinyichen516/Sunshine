package com.example.xinyichen.sunshine;

/**
 * Created by paulshao on 10/10/17.
 */

public class Temperature {
}
